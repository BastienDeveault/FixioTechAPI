// Ce fichier charge tous les steps pour Cucumber
import './inscription.steps.js';
import './connexion.steps.js';
import './rendez-vous.steps.js';
